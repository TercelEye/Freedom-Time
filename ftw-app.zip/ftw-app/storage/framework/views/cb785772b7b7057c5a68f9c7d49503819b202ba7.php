<?php $__env->startSection('content'); ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger">
<?php foreach(Session::get('error') as $message): ?>
   <?php echo e($message); ?> <br>
<?php endforeach; ?>
</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-6">
   		 <div class="panel">
	<div class="panel-content">
    	<form method="post" enctype="multipart/form-data">
   <div class="form-group">
    	<label>Category</label>
        <select name="category_id" class="form-control form-white">
        	<?php foreach($category as $row): ?>
        	<option value="<?php echo e($row->id); ?>" <?php if( Request::input('id')!=""){?> <?php echo e(($row->id== $obj->category_id?"selected":"")); ?> <?php } ?> > <?php echo e($row->title); ?></option>
            <?php endforeach; ?>
        </select>
    	
    </div>    
        
	<div class="form-group">
    	<label>Title</label>
    	<input type="text" class="form-control form-white" value="<?php echo e(isset($obj->title) ? $obj->title : ''); ?>" name="title">
    </div>
    
    <div class="form-group">
    	<label>Youtube URL</label>
    	<input type="text" class="form-control form-white" value="<?php echo e(isset($obj->youtube_vide) ? $obj->youtube_vide : ''); ?>" name="youtube_vide">
    </div>
    
     <div class="form-group">
    	<label>Pdf File</label>
    	<input type="file" class="form-control form-white" name="pdf">
    </div>
    
    <div class="form-group">
    	<label>Text</label>
    	<textarea name="text" class="form-control form-white" rows="5"><?php echo e(isset($obj->text) ? $obj->text : ''); ?></textarea>
    </div>
    
	<?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e(Request::input('id')); ?>">
    <input type="submit" class="btn btn-success"> 
     <a href="<?php echo e(url('admin/training')); ?>" class="btn btn-danger"> Close </a>
</form>
    </div>
</div>
    </div><!-- end col 6 -->
    
    <?php if(Request::input('id')!=""): ?>
    <div class="col-md-6">
        <div class="panel">
            <div class="panel-content">
            <?php 
			strtok( $obj->youtube_vide, '?');

  parse_str(strtok(''));

			?>
            <iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo e(isset($v) ? $v : ''); ?>" frameborder="0" allowfullscreen></iframe>
           <a target="_blank" href="<?php echo e(url('uploads/'.$obj->pdf)); ?>" class="btn btn-lg btn-block btn-primary">
           <i class="fa fa-file-pdf-o pull-left"></i>Download PDF</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div><!--end row-->


<?php if($category!=false){ foreach ($category as $cat):
$training = $cat->training;
?>
  		 <div class="panel">
	<div class="panel-content">
    <h2><?php echo e($cat->title); ?></h2>
<table class="table table-bordered table-striped">
<thead>
	<tr> 
    	<th>ID</th> 
        <th>Title</th> 
        <th>Text</th> 
        <th>Pdf File</th> 
        <th>Youtube URL</th>
        <th width="50"></th> 
        <th width="10"></th> 
     </tr>
    </thead>
    <tbody>
    	<?php if($training!=false): ?>
    	<?php foreach($training as $row): ?>
        	<tr>
            
            	<td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->title); ?></td>
                <td><?php echo e($row->text); ?></td>
                <td><?php echo e($row->pdf); ?></td>
                <td><?php echo e($row->youtube_vide); ?></td>
                <td><a class="btn btn-sm btn-warning" href="<?php echo e(url('admin/training?id='.$row->id)); ?>"> Edit </a></td>
                 <td>
                 <form method="post" onsubmit="return confirm('Do you really want to delete this?');" action="<?php echo e(url('admin/delete_training')); ?>">
                 	<?php echo e(csrf_field()); ?>

    				<input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                    <input type="submit" class="btn btn-sm btn-danger" value="delete">
                 </form>
                 </td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
    
</table>

</div>
</div><!-- end panel -->
<?php endforeach; } ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>