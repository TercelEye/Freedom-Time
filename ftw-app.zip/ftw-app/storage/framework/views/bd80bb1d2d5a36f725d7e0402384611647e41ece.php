<?php $__env->startSection('content'); ?>



<table class="table table-bordered table-striped">
<thead>
	<tr> 
    	<th>ID</th> 
           <th>Username</th>      
        <th>Name</th> 
        <th>Email</th> 
        <th>Paypal Email</th> 
        <th>Affiliates</th> 
        
        <th>Funds</th> 
        <th></th> 
        <th></th> 
     </tr>
    </thead>
    <tbody>
    	<?php if($affilites !=false): ?>
    	<?php foreach($affilites as $row): ?>
        	<tr class="<?php echo e(($row->is_admin==1?"success":"")); ?>">
            	<td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->username); ?></td>
                <td><?php echo e($row->fname); ?> <?php echo e($row->lname); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->paypal_email); ?></td>
                <td><?php echo e(isset($row->affiliate->sub_affiliates) ? $row->affiliate->sub_affiliates : '-'); ?></td>
                
                
                <td>$ <?php echo e(isset($row->fund->balance) ? $row->fund->balance : '0'); ?></td>
                <td>
                <?php if(isset($row->fund->balance) && $row->fund->balance > 0 && $row->is_admin == 0): ?>
                    <a class="btn btn-sm btn-success" href="<?php echo e(url('admin/wthdraw/create?user_id='.$row->id.'&amount='.$row->fund->balance)); ?>">Withdraw</a>
                <?php endif; ?>
                </td>
                <td>
                    

<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#userInfo_<?php echo e($row->id); ?>">
 info
</button>

<!-- Modal -->
<div class="modal fade" id="userInfo_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo e($row->username); ?></h4>
      </div>
      <div class="modal-body">
            <table class="table table-bordered table-hover table-striped">
            <tr>
                    <td>Name</td>
                    <td>:</td>
                    <td><?php echo e($row->fname); ?> <?php echo e($row->lname); ?></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><?php echo e($row->username); ?></td>
                </tr> 
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo e($row->email); ?></td>
                </tr>
                <tr>
                    <td>Mobile</td>
                    <td>:</td>
                    <td><?php echo e($row->tel); ?></td>
                </tr>
                <tr>
                    <td>Address</td>
                    <td>:</td>
                    <td><?php echo e($row->address); ?></td>
                </tr>
                <tr>
                    <td>City</td>
                    <td>:</td>
                    <td><?php echo e($row->city); ?></td>
                </tr>
                  <tr>
                    <td>Paypal Email</td>
                    <td>:</td>
                    <td><?php echo e($row->paypal_email); ?></td>
                </tr>
                <tr>
                    <td>Paypal</td>
                    <td>:</td>
                    <td><strong>Payment profile id</strong> : <?php echo e($row->paymentprofileid); ?> |
                <strong>Profile id</strong> : <?php echo e($row->profileid); ?></td>
                </tr>
            </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button
      </div>
    </div>
  </div>
</div>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
    
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>