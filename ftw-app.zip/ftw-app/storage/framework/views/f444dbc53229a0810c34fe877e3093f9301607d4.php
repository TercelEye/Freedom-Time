 <div class="tableWrapper table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email Address</th>
                    <th>Phone Number</th>
                    <th>Sub-Affiliates</th>
                  </tr>
                </thead>
                <tbody>
                
                   <?php $i = 0 ?>
            <?php foreach($affilites as $row): ?>
              <tr class="<?php echo e(($i++%2) ? 'bluish' : 'dd'); ?>">
                    <td><?php echo e($row->user->fname); ?> <?php echo e($row->user->lname); ?></td>
                    <td><?php echo e($row->user->email); ?></td>
                    <td><?php echo e($row->user->tel); ?></td>
                    <td><?php echo e($row->sub_affiliates); ?></td>
                  </tr>
             <?php endforeach; ?>     
               
                </tbody>
              </table>
            </div>
            
          