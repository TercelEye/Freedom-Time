<?php $__env->startSection('title','FREEDOM || Register'); ?>
<?php $__env->startSection('content'); ?> 

<style type="text/css">
small {
	color:#de2020;}
</style>
<section class="main" id="register">
	<div class="content container">
		<div class="row">
			<div class="mainDiv col-xs-12 col-xs-offset-0 col-sm-6 col-sm-offset-3">
				<div class="formWrapper">
					<a href="#"><h3 class="text-uppercase">Create An Account</h3></a>
					 <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register/'.$username)); ?>">
                     
                     
                     <div class="row">
                       <div class="col-md-12">
<?php /*?>                     <div class="input-group form-group" >
    <input type="text" class="form-control" name="security" id="security">
        <span class="input-group-addon">
            <a class='app_tooltip' data-toggle="tooltip" data-placement="left" title="Password must be at least 6 character ">
                <!-- The class CANNOT be tooltip... -->
                <i class='glyphicon glyphicon-info-sign'></i>
            </a>
        </span>
    </input>
</div>

<script type="text/javascript">
$(".app_tooltip").tooltip();
</script><?php */?>
         
             <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="invited_by" value="<?php echo e($invited_by); ?>">
						<div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
							<label for="usr">Username: <sup>*</sup></label>
							<input type="text" class="form-control" name="username"  value="<?php echo e(old('username')); ?>" id="usr">
                              <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
                        <div class="form-group<?php echo e($errors->has('fname') ? ' has-error' : ''); ?>">
							<label for="pwd">First Name: <sup>*</sup></label>
							<input type="text" class="form-control" name="fname" value="<?php echo e(old('fname')); ?>"  id="email">
                              <?php if($errors->has('fname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('fname')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
                         <div class="form-group<?php echo e($errors->has('lname') ? ' has-error' : ''); ?>">
							<label for="pwd">Last Name: <sup>*</sup></label>
							<input type="text" class="form-control" name="lname" value="<?php echo e(old('lname')); ?>"  id="email">
                              <?php if($errors->has('lname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lname')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
                    
						<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
							<label for="pwd">Email: <sup>*</sup></label>
							<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"  id="email">
                              <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<label for="pwd">Password: <sup>*</sup></label>
							  <input id="password" type="password" autocomplete="off" placeholder="Password must be at least 6 character" value="" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
                       <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
							<label for="pwd">Confirm Password: <sup>*</sup></label>
							  <input id="password-confirm" type="password" placeholder="Password must be at least 6 character" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
						</div>
                        
                        </div><!-- end col -->
                       </div><!-- end row -->
                       
                         <button class="btn btn-info">  Register Now</button> 
					<?php /*?>	<a href="#" class="btn btn-info" id="registerLink">
                        Register Now</a><?php */?>
					</form>			
				</div><!-- formWrapper -->			
			</div><!-- mainDiv -->
		</div><!-- row -->
	</div>
</section>

<?php $__env->stopSection(); ?> 

  
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>