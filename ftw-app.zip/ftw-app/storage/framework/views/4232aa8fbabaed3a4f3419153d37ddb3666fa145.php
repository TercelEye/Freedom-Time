<?php $__env->startSection('content'); ?>

<div class="row">

<div class="col-md-12">

<div class="panel">
<div class="panel-heading">
    <h2>Money Wthdrawal</h2>
</div>
	<div class="panel-content">

<table class="table table-bordered table-striped">
<thead>
	<tr> 
        <th>ID</th> 
    	<th>User</th> 
        <th>Amount</th> 
        <th>Note</th> 
           <th></th> 
           <th></th> 
     </tr>
    </thead>
    <tbody>
    	<?php foreach($withdraws as $row): ?>
        	<tr>
            	<td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->amount); ?></td>
                <td><?php echo e($row->amount); ?></td>
                <td><?php echo e($row->note); ?></td>
                <td> <a href="<?php echo e(url('admin/wthdraw/edit/'.$row->id)); ?>">view</a></td>
                <td> 
                <form action="<?php echo e(url('admin/wthdraw/delete')); ?>" method="post">
                    <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="submit" name="delete" class="btn btn-sm btn-danger" value="delete">
                </form>
              </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
    
</table>

</div>
</div><!-- end panel -->

</div><!-- end col -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>