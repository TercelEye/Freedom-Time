

<html xmlns="http://www.w3.org/1999/xhtml" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width" />
<!-- fonts -->
</head><body style="width: 100% !important;min-width: 100%;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;margin: 0;padding: 0;-moz-box-sizing: border-box;-webkit-box-sizing: border-box;box-sizing: border-box;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;text-align: left;line-height: 19px;font-size: 16px;background: linear-gradient(to right, #319ae7 0%, #287dbc 21%, #287dbc 78%, #319ae7 100%) !important">

 <center><img src="http://freedomtimeandwealth.com/assets/images/logo.png"></center><br>
 
<table class="body" data-made-with-foundation="" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;background: linear-gradient(to right, #319ae7 0%, #287dbc 21%, #287dbc 78%, #319ae7 100%) !important;height: 100%;width: 100%;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0;line-height: 19px;font-size: 16px">
<tr style="padding: 0;vertical-align: top;text-align: left">
<td class="float-center" align="center" valign="center" style="word-wrap: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;padding: 0;vertical-align: top;text-align: left;margin: 0 auto;float: none;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;line-height: 19px;font-size: 16px">
<center data-parsed="" style="width: 100%;min-width: 580px">
<table class="container float-center" style="margin-top: 7%;width: 45%;border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: center;background: #fefefe;margin: 0 auto;float: none">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<td style="word-wrap: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;padding: 0;vertical-align: top;text-align: left;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0;line-height: 19px;font-size: 16px">
<table class="spacer" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<td height="16px" style="font-size: 16px;line-height: 16px;word-wrap: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;padding: 0;vertical-align: top;text-align: left;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0"> </td>
</tr>
</tbody>
</table>
<table class="row" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%;position: relative;display: table">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<th class="small-12 large-12 columns first last" style="margin: 0 auto;padding-left: 16px;padding-bottom: 16px;padding-right: 16px;width: 564px;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;text-align: left;line-height: 19px;font-size: 16px">
<table style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%">
<tr style="padding: 0;vertical-align: top;text-align: left">
<th style="color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;text-align: left;line-height: 19px;font-size: 16px">
<center data-parsed="" style="width: 100%;min-width: 532px"> 
    <p align="center" class="text-left" style="color: #5f5f5f;font: 700 18px &quot;Open Sans&quot;, sans-serif;margin: 0;text-align: left;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;line-height: 19px;font-size: 16px;margin-bottom: 10px"><?php /*?>LOGO<?php */?></p>
</center>
</th>
<th class="expander" style="visibility: hidden;width: 0;padding: 0 !important;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0;text-align: left;line-height: 19px;font-size: 16px"></th>
</tr>
</table>
</th>
</tr>
</tbody>
</table>
<table class="row" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%;position: relative;display: table">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<th class="small-12 large-12 columns first" style="margin: 0 auto;padding-left: 16px;padding-bottom: 16px;width: 564px;padding-right: 8px;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;text-align: left;line-height: 19px;font-size: 16px">
<table style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%">
<tr style="padding: 0;vertical-align: top;text-align: left">
<th style="color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;text-align: left;line-height: 19px;font-size: 16px">
   <center data-parsed="" style="width: 100%;min-width: 532px">
    <img src="{{ url('email/img/main-pic-01.png') }}" alt="#" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;width: auto;max-width: 100%;clear: both;display: block" />
    </center>
</th>
</tr>
</table>
</th>
</tr>
</tbody>
</table>
<table class="row" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%;position: relative;display: table">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<th class="small-12 large-12 columns first" style="margin: 0 auto;padding-left: 16px;padding-bottom: 16px;width: 564px;padding-right: 8px;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;text-align: left;line-height: 19px;font-size: 16px">
<table style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%">
<tr style="padding: 0;vertical-align: top;text-align: left">
<th style="color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;text-align: left;line-height: 19px;font-size: 16px">
<h1 align="center" class="text-center" style="color: #0e436a;font: 600 24px &quot;Open Sans&quot;, sans-serif;text-align: center;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;line-height: 1.3;word-wrap: normal;margin-bottom: 10px;font-size: 34px">HOWDY?</h1>
<p align="center" class="text-center" style="color: #4a4a4a;font: 400 15px &quot;Open Sans&quot;, sans-serif;margin: 0;text-align: center;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;line-height: 19px;font-size: 16px;margin-bottom: 10px">{{ $user->fname }} {{ $user->lname }} thinks you can become a business partner in their quest<br />
to start something increadible with freedomtimeandwealth.com</p>
<p align="center" class="text-center" style="color: #4a4a4a;font: 700 15px &quot;Open Sans&quot;, sans-serif;margin: 0;text-align: center;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;line-height: 19px;font-size: 16px;margin-bottom: 10px">Accept this invite if you are ready to live the dream.</p>
</th>
</tr>
</table>
</th>
</tr>
</tbody>
</table>
<table class="row" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%;position: relative;display: table">
<tbody>
<tr style="padding: 0;vertical-align: top;text-align: left">
<th class="small-12 large-12 columns first last" style="margin: 0 auto;padding-left: 16px;padding-bottom: 16px;padding-right: 16px;width: 564px;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;text-align: left;line-height: 19px;font-size: 16px">
<table style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%">
<tr style="padding: 0;vertical-align: top;text-align: left">
<th style="color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;text-align: left;line-height: 19px;font-size: 16px">
    <center data-parsed="" style="width: 100%;min-width: 532px">
        <table class="button large rounded float-center" style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: center;width: auto !important;margin: 0 0 16px 0;float: none">
            <tr style="padding: 0;vertical-align: top;text-align: left">
                <td style="word-wrap: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;padding: 0;vertical-align: top;text-align: left;color: #0a0a0a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0;line-height: 19px;font-size: 16px">
                    <table style="border-spacing: 0;border-collapse: collapse;padding: 0;vertical-align: top;text-align: left;width: 100%">
                        <tr style="padding: 0;vertical-align: top;text-align: left">
                            <td style="background: #115d95;word-wrap: break-word;-webkit-hyphens: auto;-moz-hyphens: auto;hyphens: auto;border-collapse: collapse !important;padding: 0;vertical-align: top;text-align: left;color: #fefefe;font-family: Helvetica, Arial, sans-serif;font-weight: normal;margin: 0;line-height: 19px;font-size: 16px;border: none;border-radius: 500px"><a href="{{ $link }}" style="font: 600 15px &quot;Open Sans&quot;, sans-serif;color: #fefefe;font-family: Helvetica, Arial, sans-serif;font-weight: bold;padding: 10px 20px 10px 20px;margin: 0;text-align: left;line-height: 1.3;text-decoration: none;font-size: 20px;display: inline-block;border: 0 solid #2199e8;border-radius: 3px">ACCEPT INVITE</a></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </center>
</th>
</tr>
</table>
</th>
</tr>
</tbody></table>
    <p align="center" class="text-center" style="color: #4a4a4a;font: 300 14px &quot;Open Sans&quot;, sans-serif;margin: 0;text-align: center;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;line-height: 19px;font-size: 16px;margin-bottom: 10px">Contact: <a href="#" style="color: #4a4a4a;font-family: Helvetica, Arial, sans-serif;font-weight: normal;padding: 0;margin: 0;text-align: left;line-height: 1.3;text-decoration: none">info@freedomtimeandwealth.com</a>
    </p>

</td></tr>
</tbody>
</table>
</center></td>
</tr>

</table>




</body>
</html>
